#ifndef CSV_READER_H
#define CSV_READER_H

#include <string>
#include <fstream>
#include <vector>
#include "MarketData.h"

namespace ArbSim {
    enum CsvColumn
    {
        ColSendingTime = 0,
        ColInstrumentId,
        ColEventTypeId,
        ColBidSize,
        ColBid,
        ColAsk,
        ColAskSize,
        ColumnCount
    };

    class CsvReader {
    public:
        explicit CsvReader(const std::string& filePath);

        bool IsOpen() const;
        const std::string& GetFilePath() const;

        bool ReadNextEvent(MarketEvent& event);

    private:
        std::string filePath_;
        std::ifstream file_;

        bool ReadNextNonEmptyLine(std::string& line);

        static void StripTrailingCarriageReturn(std::string& line);
    };

} // namespace ArbSim

#endif
